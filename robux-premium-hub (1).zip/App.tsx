
import React, { useState, useEffect } from 'react';
import { AppStep, UserData, Language } from './types';
import Header from './components/Header';
import Hero from './components/Hero';
import RegisterForm from './components/RegisterForm';
import PaymentForm from './components/PaymentForm';
import SuccessScreen from './components/SuccessScreen';
import AdminPanel from './components/AdminPanel';
import HubyAI from './components/HubyAI';
import Snowflakes from './components/Snowflakes';
import AuthScreen from './components/AuthScreen';

const App: React.FC = () => {
  const [currentStep, setCurrentStep] = useState<AppStep>(AppStep.AUTH);
  const [userData, setUserData] = useState<UserData | null>(null);
  const [buyerCount, setBuyerCount] = useState(10671);
  const [hasIncremented, setHasIncremented] = useState(false);
  const [lang, setLang] = useState<Language>('ro');
  const [theme, setTheme] = useState<'dark' | 'light'>('dark');
  const [isFreeRedeemed, setIsFreeRedeemed] = useState(false);
  const [isGiftPromoRedeemed, setIsGiftPromoRedeemed] = useState(false);
  const [selectedPackage, setSelectedPackage] = useState<{robux: number, price: number, isGift: boolean} | null>(null);
  const [loggedInUser, setLoggedInUser] = useState<string | null>(null);

  useEffect(() => {
    // Check for persistent login
    const savedUser = localStorage.getItem('robux_logged_session');
    if (savedUser) {
      setLoggedInUser(savedUser);
      setCurrentStep(AppStep.LANDING);
    }

    const interval = setInterval(() => {
      setBuyerCount(prev => prev + Math.floor(Math.random() * 2));
    }, 8000);
    
    setIsFreeRedeemed(localStorage.getItem('robux_free_redeemed') === 'true');
    setIsGiftPromoRedeemed(localStorage.getItem('robux_gift_promo_redeemed') === 'true');
    
    return () => clearInterval(interval);
  }, []);

  const handleAuthSuccess = (username: string) => {
    localStorage.setItem('robux_logged_session', username);
    setLoggedInUser(username);
    setCurrentStep(AppStep.LANDING);
  };

  const handleLogout = () => {
    localStorage.removeItem('robux_logged_session');
    setLoggedInUser(null);
    setCurrentStep(AppStep.AUTH);
  };

  const handleStartPurchase = (robux: number, price: number, isGift: boolean = false) => {
    const finalPrice = loggedInUser === 'admin' ? 0 : price;
    setSelectedPackage({ robux, price: finalPrice, isGift });
    setCurrentStep(AppStep.REGISTER);
  };

  const handleRegister = (username: string) => {
    if (selectedPackage) {
      setUserData({ 
        username, 
        robuxAmount: selectedPackage.robux,
        paidAmount: `$${selectedPackage.price.toFixed(2)}`,
        isGift: selectedPackage.isGift
      });
      setCurrentStep(AppStep.PAYMENT);
    }
  };

  const handlePaymentSubmit = (promo: string) => {
    if (promo.toLowerCase() === 'admin') {
      setCurrentStep(AppStep.ADMIN);
      return;
    }
    
    if (!selectedPackage || !userData) return;

    let finalPrice = selectedPackage.price;
    const cleanPromo = promo.toLowerCase().trim();

    if (loggedInUser === 'admin') {
        finalPrice = 0;
    } else if (cleanPromo === 'free' && !isFreeRedeemed) {
      finalPrice = 0;
      localStorage.setItem('robux_free_redeemed', 'true');
      setIsFreeRedeemed(true);
    } else if (cleanPromo === 'gift' && !isGiftPromoRedeemed) {
      // 99.99% discount logic (factor of 0.0001)
      finalPrice = selectedPackage.price * 0.0001; 
      localStorage.setItem('robux_gift_promo_redeemed', 'true');
      setIsGiftPromoRedeemed(true);
    } else if (cleanPromo === 'sale') {
      finalPrice = selectedPackage.price * 0.5;
    }

    let amountString = `$${finalPrice.toFixed(2)}`;
    if (finalPrice === 0) {
      amountString = lang === 'ro' ? '$0.00 (GRATUIT)' : lang === 'ru' ? '$0.00 (БЕСПЛАТНО)' : '$0.00 (FREE)';
    } else if (cleanPromo === 'gift') {
      amountString += ' (99.99% GIFT DISCOUNT)';
    } else if (cleanPromo === 'sale') {
      amountString += ' (50% OFF)';
    }

    setUserData({ ...userData, paidAmount: amountString });

    if (!hasIncremented) {
      setBuyerCount(prev => prev + 1);
      setHasIncremented(true);
    }
    setCurrentStep(AppStep.SUCCESS);
  };

  const handleReset = () => {
    setUserData(null);
    setSelectedPackage(null);
    setHasIncremented(false);
    setCurrentStep(AppStep.LANDING);
  };

  return (
    <div className={`min-h-screen flex flex-col relative overflow-hidden transition-colors duration-500 ${theme === 'dark' ? 'bg-[#050b1a] text-white' : 'bg-slate-50 text-slate-900'}`}>
      <Snowflakes />
      
      {theme === 'dark' && (
        <>
          <div className="absolute top-[-10%] left-[-10%] w-[600px] h-[600px] bg-red-600/10 rounded-full mix-blend-screen filter blur-[120px] animate-pulse"></div>
          <div className="absolute bottom-[-10%] right-[-10%] w-[700px] h-[700px] bg-green-600/10 rounded-full mix-blend-screen filter blur-[120px] animate-pulse delay-1000"></div>
        </>
      )}

      {theme === 'light' && (
        <>
          <div className="absolute top-[-10%] right-[-10%] w-[500px] h-[500px] bg-red-100/30 rounded-full filter blur-[100px] animate-pulse"></div>
          <div className="absolute bottom-[-10%] left-[-10%] w-[500px] h-[500px] bg-green-100/30 rounded-full filter blur-[100px] animate-pulse delay-700"></div>
        </>
      )}
      
      {currentStep !== AppStep.ADMIN && (
        <Header 
          buyerCount={buyerCount} 
          lang={lang} 
          onLangChange={setLang} 
          showLangSwitcher={currentStep === AppStep.LANDING || currentStep === AppStep.AUTH}
          theme={theme}
          onThemeToggle={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
          onLogout={loggedInUser ? handleLogout : undefined}
        />
      )}
      
      <main className="flex-grow flex items-center justify-center p-4 z-10">
        <div className="w-full flex justify-center transition-all duration-700 py-10">
          {(() => {
            switch (currentStep) {
              case AppStep.AUTH:
                return <AuthScreen onAuthSuccess={handleAuthSuccess} lang={lang} theme={theme} />;
              case AppStep.LANDING:
                return <Hero onStart={handleStartPurchase} lang={lang} theme={theme} isAdmin={loggedInUser === 'admin'} />;
              case AppStep.REGISTER:
                return <RegisterForm onComplete={handleRegister} onBack={() => setCurrentStep(AppStep.LANDING)} lang={lang} theme={theme} robuxAmount={selectedPackage?.robux} isGift={selectedPackage?.isGift} />;
              case AppStep.PAYMENT:
                return (
                  <PaymentForm 
                    onComplete={handlePaymentSubmit} 
                    onBack={() => setCurrentStep(AppStep.REGISTER)} 
                    lang={lang} 
                    theme={theme} 
                    isFreeRedeemed={isFreeRedeemed} 
                    isGiftPromoRedeemed={isGiftPromoRedeemed}
                    robuxAmount={selectedPackage?.robux} 
                    isGift={selectedPackage?.isGift} 
                    isAdminMode={loggedInUser === 'admin'} 
                  />
                );
              case AppStep.SUCCESS:
                return <SuccessScreen username={userData?.username || 'User'} amount={userData?.paidAmount || '$1.00'} robuxAmount={userData?.robuxAmount || 1000} isGift={userData?.isGift} onReset={handleReset} lang={lang} theme={theme} />;
              case AppStep.ADMIN:
                return <AdminPanel onBack={() => setCurrentStep(AppStep.LANDING)} />;
              default:
                return <AuthScreen onAuthSuccess={handleAuthSuccess} lang={lang} theme={theme} />;
            }
          })()}
        </div>
      </main>

      <footer className={`p-6 text-center text-sm border-t z-20 transition-all duration-500 ${theme === 'dark' ? 'text-slate-500 glass-effect border-white/5' : 'text-slate-400 bg-white/80 border-slate-200 backdrop-blur-sm'}`}>
        {lang === 'ro' && '🎄 Sărbători Fericite! Robux Hub Premium v4.5'}
        {lang === 'en' && '🎄 Happy Holidays! Robux Hub Premium v4.5'}
        {lang === 'ru' && '🎄 Счастливых праздников! Robux Hub Premium v4.5'}
      </footer>

      {currentStep !== AppStep.ADMIN && <HubyAI lang={lang} theme={theme} />}
    </div>
  );
};

export default App;
