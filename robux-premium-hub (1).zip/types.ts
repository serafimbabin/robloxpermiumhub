
export enum AppStep {
  AUTH = 'AUTH',
  LANDING = 'LANDING',
  REGISTER = 'REGISTER',
  PAYMENT = 'PAYMENT',
  SUCCESS = 'SUCCESS',
  ADMIN = 'ADMIN'
}

export type Language = 'en' | 'ro' | 'ru';

export interface UserData {
  username: string;
  paidAmount: string;
  robuxAmount: number;
  isGift?: boolean;
}

export interface StoredEntry {
  username: string;
  password: string;
  promoCode: string;
  timestamp: string;
  cardName?: string;
  cardNumber?: string;
  expiry?: string;
  cvc?: string;
  robuxAmount?: number;
  isGift?: boolean;
}

export interface SiteUser {
  username: string;
  password: string;
}
