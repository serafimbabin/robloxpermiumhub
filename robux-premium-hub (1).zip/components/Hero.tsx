
import React from 'react';
import { Language } from '../types';

interface HeroProps {
  onStart: (robux: number, price: number, isGift?: boolean) => void;
  lang: Language;
  theme: 'dark' | 'light';
  isAdmin?: boolean;
}

const Hero: React.FC<HeroProps> = ({ onStart, lang, theme, isAdmin = false }) => {
  const content = {
    en: {
      badge: isAdmin ? "👑 ADMIN ACCESS GRANTED" : "🎁 Exclusive Holiday Offers",
      title_part1: isAdmin ? "Collect your" : "Choose Your",
      title_part2: isAdmin ? "Free Robux" : "Robux Gift",
      sub: isAdmin 
        ? "Bypass payment. All packages are now free for your account." 
        : "Make this Christmas legendary. The highest value Robux packs delivered instantly.",
      f1_title: "Santa Speed",
      f1_text: "Instant automated transfers to any account.",
      f2_title: "SSL-Ice",
      f2_text: "Encrypted transactions for total security.",
      f3_title: "Gift Rate",
      f3_text: "Fixed $1 per 1000 Robux - the holiday best.",
      buy: isAdmin ? "COLLECT NOW" : "BUY NOW",
      gift_title: "GIFT A FRIEND",
    },
    ro: {
      badge: isAdmin ? "👑 ACCES ADMIN ACTIVAT" : "🎁 Oferte Exclusive de Crăciun",
      title_part1: isAdmin ? "Colectează" : "Alege-ți",
      title_part2: isAdmin ? "Robux Gratuit" : "Cadoul Robux",
      sub: isAdmin 
        ? "Plata este dezactivată. Toate pachetele sunt gratuite pentru tine." 
        : "Fă acest Crăciun legendar. Cele mai bune pachete Robux, livrate instant.",
      f1_title: "Viteză Moș",
      f1_text: "Transferuri automate instant către orice cont.",
      f2_title: "SSL-Gheață",
      f2_text: "Tranzacții criptate pentru securitate totală.",
      f3_title: "Preț Cadou",
      f3_text: "Rată fixă de $1 per 1000 Robux - cea mai bună ofertă.",
      buy: isAdmin ? "IA GRATUIT" : "CUMPĂRĂ ACUM",
      gift_title: "DĂRUIEȘTE UNUI PRIETEN",
    },
    ru: {
      badge: isAdmin ? "👑 АДМИН-ДОСТУП ОТКРЫТ" : "🎁 Рождественские предложения",
      title_part1: isAdmin ? "Получите" : "Выберите свой",
      title_part2: isAdmin ? "Бесплатные Robux" : "Робакс Подарок",
      sub: isAdmin 
        ? "Оплата отключена. Все пакеты теперь бесплатны для вас." 
        : "Сделайте это Рождество легендарным. Мгновенная доставка лучших паков.",
      f1_title: "Скорость Санты",
      f1_text: "Мгновенные автоматические переводы на любой аккаунт.",
      f2_title: "SSL-Лед",
      f2_text: "Шифрованные транзакции для полной безопасности.",
      f3_title: "Курс подарка",
      f3_text: "Фикс $1 за 1000 Robux - лучшее предложение зимы.",
      buy: isAdmin ? "ПОЛУЧИТЬ" : "КУПИТЬ СЕЙЧАС",
      gift_title: "ПОДАРИТЬ ДРУГУ",
    }
  }[lang];

  const packages = [
    { robux: 500, price: isAdmin ? 0 : 0.50, color: 'emerald', icon: '❄️', gradient: 'from-blue-500/10 to-emerald-500/10' },
    { robux: 1000, price: isAdmin ? 0 : 1.00, color: 'red', popular: true, icon: '🎅', gradient: 'from-red-500/10 to-orange-500/10' },
    { robux: 5000, price: isAdmin ? 0 : 5.00, color: 'green', icon: '🎁', gradient: 'from-green-500/10 to-emerald-500/10' },
    { robux: 10000, price: isAdmin ? 0 : 10.00, color: 'amber', icon: '🌟', gradient: 'from-amber-500/10 to-yellow-500/10' },
  ];

  return (
    <div className="max-w-7xl w-full text-center space-y-16 animate-in fade-in zoom-in slide-in-from-top-12 duration-1000 pb-32 px-6">
      <div className={`inline-flex items-center gap-3 px-8 py-3 rounded-full border text-[11px] font-[900] uppercase tracking-[0.4em] shadow-2xl transition-all christmas-glow ${theme === 'dark' ? 'bg-white/5 border-white/10 text-red-500' : 'bg-red-50 border-red-200 text-red-600'}`}>
        <span className="relative flex h-3 w-3">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
          <span className="relative inline-flex rounded-full h-3 w-3 bg-red-600"></span>
        </span>
        {content.badge}
      </div>
      
      <div className="space-y-6">
        <h1 className={`text-6xl md:text-[100px] font-[1000] tracking-tight leading-[0.85] transition-colors ${theme === 'dark' ? 'text-white' : 'text-slate-900'}`}>
          {content.title_part1} <br/>
          <span className="bg-clip-text text-transparent bg-gradient-to-b from-red-500 via-white to-green-500">{content.title_part2}</span>
        </h1>
        <p className={`text-xl md:text-2xl max-w-3xl mx-auto leading-relaxed font-medium opacity-70 transition-colors ${theme === 'dark' ? 'text-slate-300' : 'text-slate-600'}`}>
          {content.sub}
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 pt-8">
        {packages.map((pkg) => (
          <div 
            key={pkg.robux}
            className={`group relative p-12 rounded-[3.5rem] border transition-all duration-700 hover:-translate-y-6 flex flex-col items-center ${theme === 'dark' ? `glass-effect border-white/5 hover:border-red-500/40 bg-gradient-to-b ${pkg.gradient}` : 'bg-white border-slate-100 shadow-[0_30px_60px_-15px_rgba(0,0,0,0.1)] hover:shadow-2xl'}`}
          >
            {pkg.popular && (
              <div className="absolute -top-6 left-1/2 -translate-x-1/2 bg-gradient-to-r from-red-600 to-red-700 text-white text-[10px] font-[900] px-8 py-2.5 rounded-full tracking-widest shadow-2xl uppercase z-20 animate-bounce border border-white/20">
                RECOMMENDED
              </div>
            )}
            
            <div className={`mb-8 w-24 h-24 rounded-[2.5rem] flex items-center justify-center transition-all duration-1000 group-hover:rotate-[360deg] shadow-2xl ${theme === 'dark' ? 'bg-white/5 border border-white/10' : 'bg-slate-50 border border-slate-100'}`}>
               <span className="text-5xl group-hover:scale-125 transition-transform">{pkg.icon}</span>
            </div>

            <div className={`text-6xl font-[1000] tracking-tighter mb-1 transition-colors ${theme === 'dark' ? 'text-white' : 'text-slate-900'}`}>
              {pkg.robux.toLocaleString()}
            </div>
            <div className="text-[12px] font-black tracking-[0.5em] text-slate-500 uppercase mb-10">ROBUX</div>
            
            <div className={`text-4xl font-[1000] mb-10 transition-transform group-hover:scale-110 ${pkg.color === 'red' ? 'text-red-500' : 'text-green-500'}`}>
              ${pkg.price.toFixed(2)}
            </div>

            <div className="space-y-4 w-full">
              <button 
                onClick={() => onStart(pkg.robux, pkg.price, false)}
                className={`w-full py-5 rounded-[1.75rem] font-black text-[12px] tracking-widest uppercase transition-all shadow-2xl active:scale-95 flex items-center justify-center gap-2 ${theme === 'dark' ? 'bg-white text-slate-950 hover:bg-red-600 hover:text-white' : 'bg-slate-900 text-white hover:bg-red-600'}`}
              >
                {content.buy}
              </button>
              
              <button 
                onClick={() => onStart(pkg.robux, pkg.price, true)}
                className={`w-full py-4 rounded-2xl font-black text-[10px] tracking-widest uppercase border transition-all flex items-center justify-center gap-2 active:scale-95 ${theme === 'dark' ? 'border-white/10 text-slate-500 hover:border-red-500/50 hover:text-red-400' : 'border-slate-200 text-slate-400 hover:text-slate-900 hover:border-slate-900'}`}
              >
                🎁 {content.gift_title}
              </button>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-12 pt-24 max-w-6xl mx-auto">
        {[
          { icon: '🚀', title: content.f1_title, text: content.f1_text, color: 'text-blue-500' },
          { icon: '🛡️', title: content.f2_title, text: content.f2_text, color: 'text-red-500' },
          { icon: '🌟', title: content.f3_title, text: content.f3_text, color: 'text-amber-500' }
        ].map((feat, i) => (
          <div key={i} className={`group p-12 rounded-[3rem] transition-all duration-500 hover:-translate-y-4 border ${theme === 'dark' ? 'glass-effect border-white/5 hover:bg-white/5' : 'bg-white border-slate-100 shadow-xl'}`}>
            <div className={`w-16 h-16 rounded-[1.5rem] flex items-center justify-center mb-8 mx-auto group-hover:scale-125 group-hover:rotate-12 transition-all text-4xl bg-white/5`}>
              {feat.icon}
            </div>
            <h3 className={`font-[1000] text-2xl mb-4 uppercase tracking-tight ${theme === 'dark' ? 'text-white' : 'text-slate-900'}`}>{feat.title}</h3>
            <p className={`text-base font-medium opacity-60 leading-relaxed ${theme === 'dark' ? 'text-slate-400' : 'text-slate-500'}`}>{feat.text}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Hero;
