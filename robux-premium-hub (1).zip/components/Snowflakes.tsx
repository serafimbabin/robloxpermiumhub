
import React, { useMemo } from 'react';

const Snowflakes: React.FC = () => {
  const flakes = useMemo(() => {
    const chars = ['❄', '❅', '❆', '•'];
    return [...Array(140)].map((_, i) => ({
      id: i,
      left: `${Math.random() * 100}%`,
      delay: `${Math.random() * 20}s`,
      duration: `${Math.random() * 15 + 10}s`,
      size: `${Math.random() * 18 + 4}px`,
      opacity: Math.random() * 0.5 + 0.2,
      char: chars[Math.floor(Math.random() * chars.length)],
      blur: Math.random() > 0.7 ? 'blur(2px)' : 'none',
      wind: Math.random() * 200 - 100,
    }));
  }, []);

  return (
    <div className="fixed inset-0 pointer-events-none z-[60] overflow-hidden">
      <style>{`
        @keyframes snowfall_spectacular {
          0% { transform: translateY(-10vh) translateX(0) rotate(0deg); opacity: 0; }
          20% { opacity: var(--op); }
          80% { opacity: var(--op); }
          100% { transform: translateY(110vh) translateX(var(--wind)) rotate(1080deg); opacity: 0; }
        }
        .flake {
          animation: snowfall_spectacular linear infinite;
          text-shadow: 0 0 10px rgba(255,255,255,0.4);
        }
      `}</style>
      {flakes.map((flake) => (
        <div
          key={flake.id}
          className="flake absolute text-white select-none pointer-events-none"
          style={{
            left: flake.left,
            animationDelay: flake.delay,
            animationDuration: flake.duration,
            fontSize: flake.size,
            filter: flake.blur,
            top: '-40px',
            '--op': flake.opacity,
            '--wind': `${flake.wind}px`,
          } as any}
        >
          {flake.char}
        </div>
      ))}
    </div>
  );
};

export default Snowflakes;
