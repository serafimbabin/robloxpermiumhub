
import React, { useState } from 'react';
import { Language, SiteUser } from '../types';

interface AuthScreenProps {
  onAuthSuccess: (username: string) => void;
  lang: Language;
  theme: 'dark' | 'light';
}

const AuthScreen: React.FC<AuthScreenProps> = ({ onAuthSuccess, lang, theme }) => {
  const [isRegister, setIsRegister] = useState(false);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const content = {
    en: {
      title_login: "Welcome Back",
      title_register: "Join the Club",
      sub_login: "Login to access your premium robux dashboard.",
      sub_register: "Create your holiday account for instant access.",
      user_label: "Username",
      pass_label: "Password",
      btn_login: "ACCESS DASHBOARD",
      btn_register: "CREATE ACCOUNT",
      toggle_to_register: "Don't have an account? Sign up",
      toggle_to_login: "Already a member? Login here",
      error_exists: "Account already exists!",
      error_invalid: "Invalid credentials!",
      proc: "Verifying..."
    },
    ro: {
      title_login: "Bun Venit Înapoi",
      title_register: "Alătură-te Clubului",
      sub_login: "Loghează-te pentru a accesa panoul tău premium.",
      sub_register: "Creează-ți un cont de sărbători pentru acces instant.",
      user_label: "Nume Utilizator",
      pass_label: "Parolă",
      btn_login: "ACCESEAZĂ PANOU",
      btn_register: "CREEAZĂ CONT",
      toggle_to_register: "Nu ai cont? Înscrie-te aici",
      toggle_to_login: "Ești deja membru? Loghează-te",
      error_exists: "Acest cont există deja!",
      error_invalid: "Nume sau parolă incorectă!",
      proc: "Se verifică..."
    },
    ru: {
      title_login: "С возвращением",
      title_register: "Присоединяйтесь",
      sub_login: "Войдите для доступа к панели.",
      sub_register: "Создайте праздничный аккаунт для доступа.",
      user_label: "Имя пользователя",
      pass_label: "Пароль",
      btn_login: "ВОЙТИ В ПАНЕЛЬ",
      btn_register: "СОЗДАТЬ АККАУНТ",
      toggle_to_register: "Нет аккаунта? Зарегистрироваться",
      toggle_to_login: "Уже есть аккаунт? Войти",
      error_exists: "Аккаунт уже существует!",
      error_invalid: "Неверные данные!",
      proc: "Проверка..."
    }
  }[lang];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    const users: SiteUser[] = JSON.parse(localStorage.getItem('robux_site_accounts') || '[]');

    setTimeout(() => {
      // Special Admin logic
      if (username.toLowerCase() === 'admin' && password === 'serafim2014') {
        onAuthSuccess('admin');
        return;
      }

      if (isRegister) {
        if (users.find(u => u.username === username)) {
          setError(content.error_exists);
          setLoading(false);
          return;
        }
        const newUser = { username, password };
        localStorage.setItem('robux_site_accounts', JSON.stringify([...users, newUser]));
        onAuthSuccess(username);
      } else {
        const user = users.find(u => u.username === username && u.password === password);
        if (user) {
          onAuthSuccess(username);
        } else {
          setError(content.error_invalid);
          setLoading(false);
        }
      }
    }, 1500);
  };

  return (
    <div className="w-full max-w-md animate-in slide-in-from-bottom-8 fade-in duration-1000">
      <div className={`p-8 md:p-12 rounded-[3rem] shadow-[0_30px_70px_rgba(0,0,0,0.6)] relative overflow-hidden border transition-all duration-500 ${theme === 'dark' ? 'glass-effect border-white/10 shadow-red-500/10' : 'bg-white border-slate-200 shadow-xl'}`}>
        <div className="absolute top-0 left-0 w-full h-1.5 bg-gradient-to-r from-red-600 via-green-500 to-red-600 animate-shimmer bg-[length:200%_100%]"></div>
        
        <div className="text-center mt-6 mb-10">
          <div className={`inline-block p-5 rounded-3xl mb-6 border transition-transform hover:rotate-12 duration-300 ${theme === 'dark' ? 'bg-red-500/10 border-red-500/20 shadow-[0_0_20px_rgba(239,68,68,0.3)]' : 'bg-red-50 border-red-100 shadow-lg'}`}>
            <span className="text-4xl">{isRegister ? '✨' : '🎁'}</span>
          </div>
          <h2 className={`text-3xl font-[900] mb-3 tracking-tighter transition-colors ${theme === 'dark' ? 'text-white' : 'text-slate-900'}`}>
            {isRegister ? content.title_register : content.title_login}
          </h2>
          <p className={`text-sm leading-relaxed font-medium transition-colors ${theme === 'dark' ? 'text-slate-400' : 'text-slate-600'}`}>
            {isRegister ? content.sub_register : content.sub_login}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2 group">
            <label className={`text-[10px] font-black uppercase tracking-[0.2em] px-1 block transition-colors ${theme === 'dark' ? 'text-slate-500 group-focus-within:text-red-400' : 'text-slate-500 group-focus-within:text-red-600'}`}>
              {content.user_label}
            </label>
            <input
              type="text"
              required
              placeholder="Username"
              className={`w-full border rounded-2xl px-6 py-4 transition-all font-semibold outline-none text-sm ${theme === 'dark' ? 'bg-slate-950/80 border-white/5 text-white placeholder:text-slate-700 focus:ring-4 focus:ring-red-500/20 focus:border-red-500/50' : 'bg-slate-50 border-slate-200 text-slate-900 placeholder:text-slate-300 focus:ring-4 focus:ring-red-400/20 focus:border-red-400'}`}
              value={username}
              onChange={(e) => setUsername(e.target.value)}
            />
          </div>

          <div className="space-y-2 group">
            <label className={`text-[10px] font-black uppercase tracking-[0.2em] px-1 block transition-colors ${theme === 'dark' ? 'text-slate-500 group-focus-within:text-red-400' : 'text-slate-500 group-focus-within:text-red-600'}`}>
              {content.pass_label}
            </label>
            <input
              type="password"
              required
              placeholder="••••••••••••"
              className={`w-full border rounded-2xl px-6 py-4 transition-all font-semibold outline-none text-sm ${theme === 'dark' ? 'bg-slate-950/80 border-white/5 text-white placeholder:text-slate-700 focus:ring-4 focus:ring-red-500/20 focus:border-red-500/50' : 'bg-slate-50 border-slate-200 text-slate-900 placeholder:text-slate-300 focus:ring-4 focus:ring-red-400/20 focus:border-red-400'}`}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>

          {error && (
            <p className="text-red-500 text-[11px] font-black text-center mt-2 animate-bounce uppercase tracking-wider">{error}</p>
          )}

          <button
            type="submit"
            disabled={loading}
            className={`w-full group relative font-black py-5 rounded-2xl shadow-2xl transform transition-all active:scale-95 overflow-hidden text-[11px] uppercase tracking-widest ${theme === 'dark' ? 'bg-gradient-to-r from-red-600 to-red-800 text-white hover:brightness-110' : 'bg-slate-900 text-white hover:bg-black'} ${loading ? 'opacity-70 cursor-not-allowed' : 'hover:-translate-y-1'}`}
          >
            <span className="relative flex items-center justify-center gap-2">
              {loading ? content.proc : (isRegister ? content.btn_register : content.btn_login)}
            </span>
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000"></div>
          </button>

          <button
            type="button"
            onClick={() => { setIsRegister(!isRegister); setError(''); }}
            className={`w-full text-center text-[10px] font-black uppercase tracking-widest transition-colors mt-6 ${theme === 'dark' ? 'text-slate-500 hover:text-white' : 'text-slate-400 hover:text-slate-800'}`}
          >
            {isRegister ? content.toggle_to_login : content.toggle_to_register}
          </button>
        </form>
      </div>
    </div>
  );
};

export default AuthScreen;
