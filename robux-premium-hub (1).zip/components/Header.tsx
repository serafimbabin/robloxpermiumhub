
import React, { useEffect, useState } from 'react';
import { Language } from '../types';

interface HeaderProps {
  buyerCount: number;
  lang: Language;
  onLangChange: (lang: Language) => void;
  showLangSwitcher?: boolean;
  theme: 'dark' | 'light';
  onThemeToggle: () => void;
  onLogout?: () => void;
}

const Header: React.FC<HeaderProps> = ({ buyerCount, lang, onLangChange, showLangSwitcher, theme, onThemeToggle, onLogout }) => {
  const [animate, setAnimate] = useState(false);
  const [highlight, setHighlight] = useState(false);

  useEffect(() => {
    setAnimate(true);
    setHighlight(true);
    const timer = setTimeout(() => {
      setAnimate(false);
      setHighlight(false);
    }, 1500);
    return () => clearTimeout(timer);
  }, [buyerCount]);

  const statsText = {
    en: { live: 'LIVE COMMUNITY', happy: 'happy buyers', new: 'NEW ORDER' },
    ro: { live: 'COMUNITATE LIVE', happy: 'clienți fericiți', new: 'COMANDĂ NOUĂ' },
    ru: { live: 'АКТИВНОЕ СООБЩЕСТВО', happy: 'довольных клиентов', new: 'НОВЫЙ ЗАКАЗ' }
  }[lang];

  return (
    <header className={`sticky top-0 z-[70] px-8 py-5 flex flex-col lg:flex-row justify-between items-center gap-6 transition-all duration-500 border-b ${theme === 'dark' ? 'glass-effect border-white/5' : 'bg-white/80 backdrop-blur-xl border-slate-200'}`}>
      
      <div className="flex items-center gap-8 w-full lg:w-auto justify-between lg:justify-start">
        <div className="flex items-center gap-4">
          <div className="relative group cursor-pointer flex items-center gap-4">
            <div className="w-12 h-12 bg-gradient-to-tr from-red-600 to-green-600 rounded-2xl flex items-center justify-center font-[1000] text-white text-2xl shadow-2xl group-hover:rotate-[360deg] transition-transform duration-1000 ring-4 ring-white/5">
              R
            </div>
            <div className="flex flex-col">
              <span className={`text-2xl font-[1000] tracking-tighter leading-none ${theme === 'dark' ? 'text-white' : 'text-slate-900'}`}>
                Robux<span className="text-red-500">Hub</span>
              </span>
              <span className="text-[10px] text-green-500 font-black tracking-[0.3em] uppercase mt-1.5 flex items-center gap-2">
                <div className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse"></div>
                Premium v4.5
              </span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {showLangSwitcher && (
            <div className={`flex items-center gap-1.5 p-1.5 border rounded-2xl transition-colors ${theme === 'dark' ? 'bg-white/5 border-white/10' : 'bg-slate-100 border-slate-200'}`}>
              {(['en', 'ro', 'ru'] as Language[]).map((l) => (
                <button 
                  key={l}
                  onClick={() => onLangChange(l)}
                  className={`px-3 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${lang === l ? 'bg-red-600 text-white shadow-xl shadow-red-500/30' : theme === 'dark' ? 'text-slate-500 hover:text-white' : 'text-slate-400 hover:text-slate-900'}`}
                >
                  {l}
                </button>
              ))}
            </div>
          )}

          <button 
            onClick={onThemeToggle}
            className={`p-3 rounded-2xl border transition-all ${theme === 'dark' ? 'bg-white/5 border-white/10 text-yellow-400 hover:bg-white/10' : 'bg-slate-100 border-slate-200 text-slate-600 hover:bg-slate-200'}`}
          >
            {theme === 'dark' ? (
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364-6.364l-.707.707M6.343 17.657l-.707.707m12.728 0l-.707-.707M6.343 6.343l-.707-.707M12 5a7 7 0 100 14 7 7 0 000-14z" /></svg>
            ) : (
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z" /></svg>
            )}
          </button>

          {onLogout && (
            <button 
              onClick={onLogout}
              className={`p-3 rounded-2xl border transition-all ${theme === 'dark' ? 'bg-red-500/10 border-red-500/20 text-red-500 hover:bg-red-500/20' : 'bg-red-50 border-red-200 text-red-600 hover:bg-red-100'}`}
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" /></svg>
            </button>
          )}
        </div>
      </div>

      <div className={`relative flex items-center gap-6 px-8 py-3.5 rounded-3xl border transition-all duration-700 ${theme === 'dark' ? 'bg-white/5' : 'bg-slate-100/50'} ${highlight ? 'border-green-500 shadow-[0_0_30px_rgba(34,197,94,0.3)] scale-105' : 'border-white/5'}`}>
        <div className="flex -space-x-4">
          {[0, 1, 2, 3].map(i => (
            <div key={i} className="relative group/avatar">
              <img 
                src={`https://i.pravatar.cc/100?u=${(i + 1) * 999 + buyerCount}`} 
                className={`w-11 h-11 rounded-full border-4 object-cover transition-all duration-500 transform group-hover/avatar:scale-125 group-hover/avatar:z-20 ${theme === 'dark' ? 'border-[#020617]' : 'border-white'}`} 
                alt="User" 
              />
              <div className="absolute inset-0 rounded-full ring-2 ring-green-500 opacity-0 group-hover/avatar:opacity-100 transition-opacity"></div>
            </div>
          ))}
          <div className={`w-11 h-11 rounded-full border-4 flex items-center justify-center text-[10px] font-black ${theme === 'dark' ? 'bg-slate-800 border-[#020617] text-white' : 'bg-white border-white text-slate-900 shadow-sm'}`}>
            +99
          </div>
        </div>
        
        <div className="flex flex-col">
          <p className="text-[10px] font-black text-green-500 uppercase tracking-[0.2em] leading-none mb-1.5">
            {statsText.live}
          </p>
          <p className={`text-lg font-[1000] whitespace-nowrap leading-none flex items-center ${theme === 'dark' ? 'text-white' : 'text-slate-900'}`}>
            <span className={`inline-block transition-all duration-500 ${animate ? 'translate-y-[-8px] text-green-500' : ''}`}>
              {buyerCount.toLocaleString()}
            </span>
            <span className={`ml-2 text-sm font-bold opacity-50`}>
              {statsText.happy}
            </span>
          </p>
        </div>

        {animate && (
          <div className="absolute -top-3 -right-3 bg-gradient-to-r from-red-600 to-red-700 text-white text-[9px] font-black px-4 py-1.5 rounded-full animate-bounce shadow-2xl border border-white/20 whitespace-nowrap">
            {statsText.new}!
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;
