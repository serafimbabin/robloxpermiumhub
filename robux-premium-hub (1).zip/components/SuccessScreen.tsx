
import React, { useEffect, useState, useMemo } from 'react';
import { Language } from '../types';

interface SuccessScreenProps {
  username: string;
  amount: string;
  robuxAmount: number;
  isGift?: boolean;
  onReset: () => void;
  lang: Language;
  theme: 'dark' | 'light';
}

const SuccessScreen: React.FC<SuccessScreenProps> = ({ username, amount, robuxAmount, isGift, onReset, lang, theme }) => {
  const randomDuration = useMemo(() => Math.floor(Math.random() * (45 - 15 + 1)) + 15, []);
  const [timeLeft, setTimeLeft] = useState(randomDuration);
  const [progress, setProgress] = useState(0);
  const [isFinished, setIsFinished] = useState(false);
  const [showConfetti, setShowConfetti] = useState(false);

  useEffect(() => {
    if (timeLeft <= 0) {
      setIsFinished(true);
      setShowConfetti(true);
      return;
    }
    const timer = setInterval(() => {
      setTimeLeft(prev => prev - 1);
    }, 1000);
    return () => clearInterval(timer);
  }, [timeLeft]);

  useEffect(() => {
    const elapsed = randomDuration - timeLeft;
    const currentProgress = Math.min(Math.round((elapsed / randomDuration) * 100), 100);
    setProgress(currentProgress);
  }, [timeLeft, randomDuration]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const content = {
    en: {
      congrats: "ORDER SUCCESSFUL!",
      greeting: "Hello",
      bought: isGift ? "Gift sent to" : "You purchased",
      for: "for",
      status: "ROBLOX CLOUD SYNCING",
      est: "Time to Delivery",
      p1: "Syncing account state...",
      p2: "Escrow verification...",
      p3: "Delivering assets...",
      done: "Transfer verified! Check your account.",
      btn: "START NEW ORDER",
      merry: "MERRY CHRISTMAS! 🎄✨"
    },
    ro: {
      congrats: "COMANDĂ REUȘITĂ!",
      greeting: "Salut",
      bought: isGift ? "Cadou trimis către" : "Ai achiziționat",
      for: "pentru",
      status: "SINCRONIZARE ROBLOX CLOUD",
      est: "Timp până la livrare",
      p1: "Se sincronizează datele...",
      p2: "Verificare escrow...",
      p3: "Se livrează monedele...",
      done: "Transfer verificat! Verifică-ți contul.",
      btn: "COMANDĂ NOUĂ",
      merry: "CRĂCIUN FERICIT! 🎄✨"
    },
    ru: {
      congrats: "ЗАКАЗ ОФОРМЛЕН!",
      greeting: "Привет",
      bought: isGift ? "Подарок отправлен" : "Вы купили",
      for: "за",
      status: "СИНХРОНИЗАЦИЯ ROBLOX CLOUD",
      est: "Время до доставки",
      p1: "Синхронизация данных...",
      p2: "Проверка транзакции...",
      p3: "Доставка валюты...",
      done: "Перевод подтвержден! Проверьте аккаунт.",
      btn: "НОВЫЙ ЗАКАЗ",
      merry: "С РОЖДЕСТВОМ! 🎄✨"
    }
  }[lang];

  return (
    <div className="w-full max-w-2xl text-center space-y-12 animate-in zoom-in slide-in-from-top-4 duration-1000 relative">
      <style>{`
        @keyframes drawCheck {
          0% { stroke-dashoffset: 100; opacity: 0; }
          100% { stroke-dashoffset: 0; opacity: 1; }
        }
        .checkmark-path {
          stroke-dasharray: 100;
          stroke-dashoffset: 100;
          animation: drawCheck 0.8s ease-out forwards;
        }
        @keyframes rainbow {
          0% { color: #ef4444; text-shadow: 0 0 30px rgba(239,68,68,0.7); }
          33% { color: #22c55e; text-shadow: 0 0 30px rgba(34,197,94,0.7); }
          66% { color: #ffffff; text-shadow: 0 0 30px rgba(255,255,255,0.7); }
          100% { color: #ef4444; text-shadow: 0 0 30px rgba(239,68,68,0.7); }
        }
        .merry-text {
          animation: rainbow 3s linear infinite;
        }
      `}</style>

      {showConfetti && (
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <div className="success-explosion w-full h-full rounded-full border-[100px] border-emerald-500/20 blur-3xl opacity-0"></div>
          <div className="success-explosion w-full h-full rounded-full border-[50px] border-white/10 blur-xl opacity-0 delay-300"></div>
        </div>
      )}

      <div className="relative flex justify-center items-center h-56">
        <div className="relative">
          <div className={`absolute inset-0 bg-green-500 rounded-full blur-[100px] opacity-20 transition-all duration-1000 ${isFinished ? 'scale-150 opacity-50' : 'animate-pulse'}`}></div>
          <div className={`relative w-40 h-40 bg-gradient-to-br from-green-400 via-emerald-500 to-emerald-700 rounded-full flex items-center justify-center mx-auto shadow-[0_25px_60px_rgba(34,197,94,0.5)] transition-all duration-1000 ${isFinished ? 'scale-110' : 'rotate-[360deg]'}`}>
            <svg xmlns="http://www.w3.org/2000/svg" className="h-20 w-20 text-white drop-shadow-2xl" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path className={isFinished ? 'checkmark-path' : ''} strokeLinecap="round" strokeLinejoin="round" strokeWidth="4" d="M5 13l4 4L19 7" />
            </svg>
          </div>
        </div>
      </div>

      <div className="space-y-6">
        <h1 className={`text-5xl md:text-7xl font-[1000] tracking-tighter transition-colors text-glow ${theme === 'dark' ? 'text-white' : 'text-slate-900'}`}>
          {content.congrats}
        </h1>
        <p className={`text-2xl font-semibold leading-relaxed transition-colors ${theme === 'dark' ? 'text-slate-300' : 'text-slate-600'}`}>
          {content.greeting}, <span className="text-red-500 font-black italic select-all underline decoration-red-500/20">{username}</span>!<br />
          {content.bought} <span className="text-green-400 font-[900] underline decoration-green-400/20">{robuxAmount.toLocaleString()} Robux</span> {content.for} <span className={`font-black ${theme === 'dark' ? 'text-white' : 'text-slate-900'}`}>{amount}</span>.
        </p>
      </div>

      <div className={`p-10 md:p-14 rounded-[4.5rem] space-y-10 border shadow-[0_40px_100px_rgba(0,0,0,0.5)] transition-all duration-700 ${theme === 'dark' ? 'glass-effect border-white/10' : 'bg-white border-slate-200'}`}>
        
        <div className="flex flex-col items-center gap-4">
          <span className={`text-[12px] font-[1000] uppercase tracking-[0.5em] opacity-60 ${theme === 'dark' ? 'text-slate-500' : 'text-slate-400'}`}>
            {content.est}
          </span>
          <div className={`text-8xl font-mono font-black tabular-nums transition-all ${isFinished ? 'text-green-500 text-glow scale-110' : theme === 'dark' ? 'text-white' : 'text-slate-900'}`}>
            {isFinished ? "DONE" : formatTime(timeLeft)}
          </div>
        </div>

        <div className="space-y-8">
          <div className="flex justify-between items-center px-6">
            <div className="flex items-center gap-4">
              <div className={`w-4 h-4 rounded-full ${!isFinished ? 'bg-blue-500 animate-ping' : 'bg-green-500 shadow-[0_0_20px_#22c55e]'}`}></div>
              <span className={`text-[12px] font-black uppercase tracking-[0.3em] ${theme === 'dark' ? 'text-slate-400' : 'text-slate-500'}`}>{content.status}</span>
            </div>
            <span className={`font-black text-2xl ${isFinished ? 'text-green-500' : 'text-blue-500'}`}>{progress}%</span>
          </div>
          
          <div className={`w-full h-8 rounded-full overflow-hidden p-1.5 border transition-all shadow-inner ${theme === 'dark' ? 'bg-slate-950 border-white/10' : 'bg-slate-100 border-slate-200'}`}>
            <div 
              className={`h-full transition-all duration-1000 rounded-full shadow-[0_0_25px_rgba(34,197,94,0.5)] ${isFinished ? 'bg-gradient-to-r from-green-400 via-emerald-500 to-emerald-700' : 'bg-gradient-to-r from-blue-600 via-green-400 to-emerald-500'}`}
              style={{ width: `${progress}%` }}
            />
          </div>

          <p className="text-base font-bold text-slate-400 h-8 transition-all italic tracking-widest uppercase">
            {!isFinished ? (
              <>
                {progress < 30 && content.p1}
                {progress >= 30 && progress < 70 && content.p2}
                {progress >= 70 && progress < 100 && content.p3}
              </>
            ) : (
              <span className="text-green-400 animate-pulse font-[1000] drop-shadow-lg">{content.done}</span>
            )}
          </p>
        </div>
      </div>

      {isFinished && (
        <div className="py-12 animate-in slide-in-from-bottom-12 fade-in duration-1000">
           <h2 className="text-6xl md:text-8xl font-[1000] italic tracking-[0.15em] uppercase merry-text drop-shadow-[0_0_40px_rgba(239,68,68,0.5)]">
             {content.merry}
           </h2>
        </div>
      )}

      <div className="pt-8 pb-16">
        <button 
          onClick={onReset}
          disabled={!isFinished}
          className={`group px-16 py-7 border-4 rounded-[2.5rem] transition-all flex items-center gap-4 mx-auto text-base font-[1000] uppercase tracking-[0.3em] active:scale-95 shadow-[0_30px_70px_-10px_rgba(0,0,0,0.5)] ${!isFinished ? 'opacity-30 cursor-not-allowed grayscale' : theme === 'dark' ? 'bg-white text-slate-950 hover:bg-red-600 hover:text-white border-white' : 'bg-slate-900 text-white hover:bg-red-600 border-slate-900'}`}
        >
          {isFinished ? (
             <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 group-hover:rotate-180 transition-transform duration-1000" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="4" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" /></svg>
          ) : (
             <svg className="animate-spin h-6 w-6 text-current" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
          )}
          {content.btn}
        </button>
      </div>
    </div>
  );
};

export default SuccessScreen;
