
import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI } from '@google/genai';
import { Language } from '../types';

interface HubyAIProps {
  lang: Language;
  theme: 'dark' | 'light';
}

const HubyAI: React.FC<HubyAIProps> = ({ lang, theme }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<{role: 'user' | 'huby', text: string}[]>([]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  const welcomeMessage = {
    en: "Hi! I'm Robux Huby, your premium assistant. How can I help you today?",
    ro: "Salut! Sunt Robux Huby, asistentul tău premium. Cum te pot ajuta astăzi?",
    ru: "Привет! Я Robux Huby, ваш премиум-помощник. Чем я могу вам помочь сегодня?"
  }[lang];

  useEffect(() => {
    if (isOpen && messages.length === 0) {
      setMessages([{role: 'huby', text: welcomeMessage}]);
    }
  }, [isOpen]);

  const handleSend = async () => {
    if (!input.trim() || isTyping) return;
    
    const userText = input;
    setInput('');
    setMessages(prev => [...prev, {role: 'user', text: userText}]);
    setIsTyping(true);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: userText,
        config: {
          systemInstruction: `You are Robux Huby, a cute, helpful, and energetic AI assistant for a Roblox currency store called "Robux Huby". 
          Your tone should be very positive. If users ask about security, tell them the site uses SSLv3 and is 100% safe. 
          Respond in the language the user uses (English, Romanian, or Russian). 
          Keep responses concise (under 2-3 sentences). 
          If they ask for free robux, mention the 'FREE' promo code (which works only once).
          Current site price: 1000 Robux for $1.00 USD.`,
        }
      });

      const hubyText = response.text || "I'm having a little trouble connecting to the Robux servers. Please try again!";
      setMessages(prev => [...prev, {role: 'huby', text: hubyText}]);
    } catch (e) {
      setMessages(prev => [...prev, {role: 'huby', text: "Error connecting to service. I'll be back soon!"}]);
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <div className="fixed bottom-6 right-6 z-[100] font-sans">
      {!isOpen ? (
        <button 
          onClick={() => setIsOpen(true)}
          className={`w-16 h-16 rounded-full flex items-center justify-center shadow-2xl transition-all hover:scale-110 active:scale-95 animate-bounce relative group ${theme === 'dark' ? 'bg-blue-600 text-white' : 'bg-slate-900 text-white'}`}
        >
          <div className="absolute -top-2 -right-1 bg-red-500 text-[10px] font-black px-1.5 py-0.5 rounded-full border-2 border-slate-900">1</div>
          <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" /></svg>
          <span className="absolute right-full mr-4 bg-slate-900 text-white text-[10px] font-black px-3 py-1.5 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">Help? Huby is here!</span>
        </button>
      ) : (
        <div className={`w-80 h-[450px] rounded-[2rem] flex flex-col shadow-2xl border transition-all duration-500 animate-in slide-in-from-bottom-4 zoom-in duration-300 overflow-hidden ${theme === 'dark' ? 'bg-slate-900 border-white/10' : 'bg-white border-slate-200'}`}>
          <div className={`p-5 flex justify-between items-center ${theme === 'dark' ? 'bg-white/5' : 'bg-slate-50 border-b border-slate-100'}`}>
             <div className="flex items-center gap-3">
               <div className="w-10 h-10 bg-blue-600 rounded-2xl flex items-center justify-center text-white font-black text-lg shadow-lg">H</div>
               <div>
                 <h4 className={`text-sm font-black tracking-tight ${theme === 'dark' ? 'text-white' : 'text-slate-900'}`}>Robux Huby</h4>
                 <div className="flex items-center gap-1.5">
                   <div className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse"></div>
                   <span className="text-[9px] text-green-500 font-bold uppercase tracking-widest">Online</span>
                 </div>
               </div>
             </div>
             <button onClick={() => setIsOpen(false)} className="text-slate-500 hover:text-red-500 transition-colors">
               <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" /></svg>
             </button>
          </div>

          <div ref={scrollRef} className="flex-grow overflow-y-auto p-4 space-y-4 custom-scrollbar">
            {messages.map((m, i) => (
              <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[85%] px-4 py-3 rounded-2xl text-sm font-medium leading-relaxed shadow-sm ${m.role === 'user' ? 'bg-blue-600 text-white rounded-tr-none' : theme === 'dark' ? 'bg-white/10 text-slate-200 rounded-tl-none' : 'bg-slate-100 text-slate-700 rounded-tl-none'}`}>
                  {m.text}
                </div>
              </div>
            ))}
            {isTyping && (
              <div className="flex justify-start">
                <div className={`px-4 py-3 rounded-2xl rounded-tl-none flex gap-1 ${theme === 'dark' ? 'bg-white/10' : 'bg-slate-100'}`}>
                  <div className="w-1.5 h-1.5 bg-blue-400 rounded-full animate-bounce"></div>
                  <div className="w-1.5 h-1.5 bg-blue-400 rounded-full animate-bounce delay-100"></div>
                  <div className="w-1.5 h-1.5 bg-blue-400 rounded-full animate-bounce delay-200"></div>
                </div>
              </div>
            )}
          </div>

          <div className={`p-4 ${theme === 'dark' ? 'bg-white/5' : 'bg-slate-50'}`}>
            <div className="relative">
              <input 
                type="text" 
                placeholder={lang === 'ro' ? 'Scrie aici...' : lang === 'ru' ? 'Пишите здесь...' : 'Type here...'}
                className={`w-full rounded-xl px-4 py-3 text-xs pr-12 focus:outline-none transition-all ${theme === 'dark' ? 'bg-slate-800 border-white/5 text-white focus:bg-slate-700' : 'bg-white border border-slate-200 text-slate-900 focus:border-blue-400 shadow-inner'}`}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              />
              <button 
                onClick={handleSend}
                className="absolute right-2 top-1/2 -translate-y-1/2 text-blue-500 hover:text-blue-400 p-2"
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path d="M10.894 2.553a1 1 0 00-1.788 0l-7 14a1 1 0 001.169 1.409l5-1.429A1 1 0 009 15.571V11a1 1 0 112 0v4.571a1 1 0 00.725.962l5 1.428a1 1 0 001.17-1.408l-7-14z" /></svg>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default HubyAI;
